export const validEmail = new RegExp(
    '^[a-zA-Z].[a-zA-Z]+@/cogoport.com/'
 );
 export const validPassword = new RegExp('^(?=.*?[A-Za-z])(?=.*?[0-9]).{6,}$');