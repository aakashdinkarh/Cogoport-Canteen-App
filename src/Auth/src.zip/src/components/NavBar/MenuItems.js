export const MenuItems=[
    {
        title:'Home',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'About',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'Menu',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'Staff',
        url:'#',
        cName:'nav-links'
    },
    {
        title:'Contacts',
        url:'#',
        cName:'nav-links'
    }

]